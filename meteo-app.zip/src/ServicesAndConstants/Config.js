
const CONFIG_CONSTANTS={
 citySearchApi:"https://api.weatherapi.com/v1/search.json?key=3b91d9511f334f59a07221632241306&q=",
 WeatherApi:"http://api.weatherapi.com/v1/forecast.json",
 WeatherApiKey:"3b91d9511f334f59a07221632241306",
villes:['Rabat','orleans','Toulon','Paris','marseille']
}
export default CONFIG_CONSTANTS;